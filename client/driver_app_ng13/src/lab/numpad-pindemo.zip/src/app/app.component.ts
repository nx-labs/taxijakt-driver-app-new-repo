    import { Component } from '@angular/core';
    import { MbscNumpadOptions } from '../lib/mobiscroll/js/mobiscroll.angular.min.js';
    
    @Component({
        selector: 'app-root',
        templateUrl: './app.component.html'
    })
    export class AppComponent {
        numpad: number;
    
        numpadSettings: MbscNumpadOptions = {
            theme: 'ios',            // Specify theme like: theme: 'ios' or omit setting to use default
        themeVariant: 'light',       // More info about themeVariant: https://docs.mobiscroll.com/4-10-9/angular/numpad#opt-themeVariant
        lang: 'en',                  // Specify language like: lang: 'pl' or omit setting to use default
            template: 'dddd',        // More info about template: https://docs.mobiscroll.com/4-10-9/angular/numpad#opt-template
            allowLeadingZero: true,  // More info about allowLeadingZero: https://docs.mobiscroll.com/4-10-9/angular/numpad#opt-allowLeadingZero
            placeholder: '-',        // More info about placeholder: https://docs.mobiscroll.com/4-10-9/angular/numpad#opt-placeholder
            mask: '*',               // More info about mask: https://docs.mobiscroll.com/4-10-9/angular/numpad#opt-mask
            validate: (event) => {   // More info about validate: https://docs.mobiscroll.com/4-10-9/angular/numpad#event-validate
                return {
                    disabled: [],    // More info about disabled: https://docs.mobiscroll.com/4-10-9/angular/numpad#opt-disabled
                    invalid: event.values.length !== 4
                };
            }
        };
    }
